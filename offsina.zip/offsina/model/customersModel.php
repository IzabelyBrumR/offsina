<?php

namespace Model;
require_once 'conexaoMysql.php';

use ConexaoMysql;
use Exception;

class customersModel
{
    protected $id;
   
    //TODO: Insira as propriedades dos clientes aqui.
    

    //TODO: Crie os métodos acessores e modificadores aqui.

    public function __construct()
    {
        
    }
  
    public function loadAll(){
        $con = new ConexaoMysql();
        $con->Conectar();

        $sql = 'SELECT * FROM customers;';

        $resultList = $con->Consultar($sql);

        return $resultList;
    }

    
}
